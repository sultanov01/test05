var data =  [
    {
      "name": "Iphone XR",
      "someText": "6 Gb ОЗУ 128 Встроенная ",
      "price": "50 000",
      "status": "Active",
      "id": 1
    },
    {
      "name": "Iphone X",
      "someText": "8/512 led ",
      "price": "40 000",
      "status": "Active",
      "id": 2
    },
    {
      "name": "Huawei",
      "someText": "4 Gb 500TB",
      "price": "120 000",
      "status": "Active",
      "id": 3
    },
    {
      "name": "Sony PS5",
      "someText": "500GB 1 month ",
      "price": "100 000",
      "status": "Not active",
      "id": 4,
      "productGroup": ""
    },
    {
      "name": "Huawei",
      "someText": "seFefSEF",
      "price": "50 000",
      "status": "Not Active",
      "id": 6
    }
  ]

 let template = document.querySelector('#template').innerHTML;
 console.log(template);

 let compiledTemplate = Handlebars.compile(template);

 let finishTemplate = compiledTemplate(data);

 document.querySelector('#root').innerHTML = finishTemplate;